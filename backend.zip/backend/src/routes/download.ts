import express from 'express';
import { readFile } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import puppeteer from 'puppeteer';
import type { PortfolioData } from '../types/index.js';

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Generate PDF from portfolio data
async function generatePDF(portfolioData: PortfolioData): Promise<Buffer> {
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    
    // Create HTML content
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; color: #333; }
          h1 { color: #0077b6; border-bottom: 3px solid #0077b6; padding-bottom: 10px; }
          h2 { color: #0077b6; margin-top: 30px; border-bottom: 2px solid #0077b6; padding-bottom: 5px; }
          h3 { color: #333; margin-top: 20px; }
          .section { margin-bottom: 30px; }
          .skill-category { margin-bottom: 15px; }
          .skill-item { margin-left: 20px; margin-bottom: 5px; }
          .experience-item, .project-item { margin-bottom: 20px; padding: 15px; background: #f5f5f5; border-radius: 5px; }
          .date { color: #666; font-style: italic; }
          ul { margin-left: 20px; }
          .contact-info { margin-top: 10px; }
        </style>
      </head>
      <body>
        <h1>${portfolioData.personal.name}</h1>
        <p><strong>${portfolioData.personal.title}</strong></p>
        <p>${portfolioData.personal.tagline}</p>
        
        <div class="section">
          <h2>About</h2>
          <p>${portfolioData.about}</p>
        </div>
        
        <div class="section">
          <h2>Skills</h2>
          ${Object.entries(
            portfolioData.skills.reduce((acc, skill) => {
              if (!acc[skill.category]) acc[skill.category] = [];
              acc[skill.category].push(skill);
              return acc;
            }, {} as Record<string, typeof portfolioData.skills>)
          ).map(([category, skills]) => `
            <div class="skill-category">
              <h3>${category}</h3>
              ${skills.map(skill => `
                <div class="skill-item">• ${skill.name} (${skill.proficiency}%)</div>
              `).join('')}
            </div>
          `).join('')}
        </div>
        
        <div class="section">
          <h2>Experience</h2>
          ${portfolioData.experience.map(exp => `
            <div class="experience-item">
              <h3>${exp.title} - ${exp.organization}</h3>
              <p class="date">${exp.startDate} - ${exp.endDate}</p>
              <p>${exp.description}</p>
              ${exp.highlights ? `
                <ul>
                  ${exp.highlights.map(h => `<li>${h}</li>`).join('')}
                </ul>
              ` : ''}
            </div>
          `).join('')}
        </div>
        
        <div class="section">
          <h2>Education</h2>
          ${portfolioData.education.map(edu => `
            <div class="experience-item">
              <h3>${edu.degree}</h3>
              <p><strong>${edu.institution}</strong> - ${edu.date}</p>
              ${edu.description ? `<p>${edu.description}</p>` : ''}
            </div>
          `).join('')}
        </div>
        
        <div class="section">
          <h2>Projects</h2>
          ${portfolioData.projects.map(proj => `
            <div class="project-item">
              <h3>${proj.title}</h3>
              <p>${proj.description}</p>
              <p><strong>Technologies:</strong> ${proj.technologies.join(', ')}</p>
              <p><strong>Categories:</strong> ${proj.categories.join(', ')}</p>
            </div>
          `).join('')}
        </div>
        
        ${portfolioData.achievements.length > 0 ? `
          <div class="section">
            <h2>Achievements</h2>
            ${portfolioData.achievements.map(ach => `
              <div class="experience-item">
                <h3>${ach.title}</h3>
                ${ach.date ? `<p class="date">${ach.date}</p>` : ''}
                <p>${ach.description}</p>
              </div>
            `).join('')}
          </div>
        ` : ''}
        
        <div class="section">
          <h2>Contact</h2>
          <div class="contact-info">
            <p><strong>Email:</strong> ${portfolioData.contact.email}</p>
            ${portfolioData.contact.phone ? `<p><strong>Phone:</strong> ${portfolioData.contact.phone}</p>` : ''}
            ${portfolioData.contact.location ? `<p><strong>Location:</strong> ${portfolioData.contact.location}</p>` : ''}
            ${portfolioData.contact.socialLinks.map(link => `
              <p><strong>${link.platform}:</strong> ${link.url}</p>
            `).join('')}
          </div>
        </div>
      </body>
      </html>
    `;
    
    await page.setContent(html);
    const pdf = await page.pdf({
      format: 'A4',
      margin: { top: '20mm', right: '20mm', bottom: '20mm', left: '20mm' },
      printBackground: true
    });
    
    return pdf;
  } finally {
    await browser.close();
  }
}

// Generate plain text from portfolio data
function generatePlainText(portfolioData: PortfolioData): string {
  let text = '';
  
  text += `${portfolioData.personal.name}\n`;
  text += `${portfolioData.personal.title}\n`;
  text += `${portfolioData.personal.tagline}\n`;
  text += `${'='.repeat(60)}\n\n`;
  
  text += `ABOUT\n${'-'.repeat(60)}\n${portfolioData.about}\n\n`;
  
  text += `SKILLS\n${'-'.repeat(60)}\n`;
  const skillsByCategory = portfolioData.skills.reduce((acc, skill) => {
    if (!acc[skill.category]) acc[skill.category] = [];
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, typeof portfolioData.skills>);
  
  Object.entries(skillsByCategory).forEach(([category, skills]) => {
    text += `\n${category}:\n`;
    skills.forEach(skill => {
      text += `  • ${skill.name} (${skill.proficiency}%)\n`;
    });
  });
  text += '\n';
  
  text += `EXPERIENCE\n${'-'.repeat(60)}\n`;
  portfolioData.experience.forEach(exp => {
    text += `\n${exp.title} - ${exp.organization}\n`;
    text += `${exp.startDate} - ${exp.endDate}\n`;
    text += `${exp.description}\n`;
    if (exp.highlights) {
      exp.highlights.forEach(h => text += `  • ${h}\n`);
    }
  });
  text += '\n';
  
  text += `EDUCATION\n${'-'.repeat(60)}\n`;
  portfolioData.education.forEach(edu => {
    text += `\n${edu.degree}\n`;
    text += `${edu.institution} - ${edu.date}\n`;
    if (edu.description) text += `${edu.description}\n`;
  });
  text += '\n';
  
  text += `PROJECTS\n${'-'.repeat(60)}\n`;
  portfolioData.projects.forEach(proj => {
    text += `\n${proj.title}\n`;
    text += `${proj.description}\n`;
    text += `Technologies: ${proj.technologies.join(', ')}\n`;
    text += `Categories: ${proj.categories.join(', ')}\n`;
  });
  text += '\n';
  
  if (portfolioData.achievements.length > 0) {
    text += `ACHIEVEMENTS\n${'-'.repeat(60)}\n`;
    portfolioData.achievements.forEach(ach => {
      text += `\n${ach.title}`;
      if (ach.date) text += ` (${ach.date})`;
      text += `\n${ach.description}\n`;
    });
    text += '\n';
  }
  
  text += `CONTACT\n${'-'.repeat(60)}\n`;
  text += `Email: ${portfolioData.contact.email}\n`;
  if (portfolioData.contact.phone) text += `Phone: ${portfolioData.contact.phone}\n`;
  if (portfolioData.contact.location) text += `Location: ${portfolioData.contact.location}\n`;
  portfolioData.contact.socialLinks.forEach(link => {
    text += `${link.platform}: ${link.url}\n`;
  });
  
  return text;
}

router.get('/:format', async (req, res) => {
  try {
    const { format } = req.params;
    
    if (format !== 'pdf' && format !== 'txt') {
      return res.status(400).json({
        success: false,
        message: 'Invalid format. Use "pdf" or "txt"'
      });
    }

    // Read portfolio data
    const dataPath = join(__dirname, '../../data/portfolio.json');
    const data = await readFile(dataPath, 'utf-8');
    const portfolioData: PortfolioData = JSON.parse(data);

    const filename = `${portfolioData.personal.name.replace(/\s+/g, '_')}_CV`;

    if (format === 'pdf') {
      const pdf = await generatePDF(portfolioData);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}.pdf"`);
      res.send(pdf);
    } else {
      const text = generatePlainText(portfolioData);
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}.txt"`);
      res.send(text);
    }
  } catch (error) {
    console.error('Error generating download:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate download'
    });
  }
});

export default router;
