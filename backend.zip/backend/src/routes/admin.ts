import express from 'express';
import { body, validationResult } from 'express-validator';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { readFile, writeFile, copyFile } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import type { PortfolioData } from '../types/index.js';

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Authentication middleware
const authenticateToken = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required'
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default-secret');
    (req as any).user = decoded;
    next();
  } catch (error) {
    return res.status(403).json({
      success: false,
      message: 'Invalid or expired token'
    });
  }
};

// Login endpoint
router.post('/login', [
  body('username').trim().notEmpty(),
  body('password').notEmpty()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    const { username, password } = req.body;

    // Check credentials
    if (username !== process.env.ADMIN_USERNAME) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    const passwordHash = process.env.ADMIN_PASSWORD_HASH || '';
    const isValid = await bcrypt.compare(password, passwordHash);

    if (!isValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { username },
      process.env.JWT_SECRET || 'default-secret',
      { expiresIn: '24h' }
    );

    res.json({
      success: true,
      token
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed'
    });
  }
});

// Update portfolio data
router.put('/portfolio', authenticateToken, async (req, res) => {
  try {
    const portfolioData: PortfolioData = req.body;

    // Basic validation
    if (!portfolioData.personal || !portfolioData.contact) {
      return res.status(400).json({
        success: false,
        message: 'Invalid portfolio data structure'
      });
    }

    const dataPath = join(__dirname, '../../data/portfolio.json');
    const backupPath = join(__dirname, '../../data/portfolio.backup.json');

    // Create backup
    try {
      await copyFile(dataPath, backupPath);
    } catch (error) {
      console.warn('Could not create backup:', error);
    }

    // Write new data atomically
    const tempPath = dataPath + '.tmp';
    await writeFile(tempPath, JSON.stringify(portfolioData, null, 2), 'utf-8');
    await copyFile(tempPath, dataPath);

    res.json({
      success: true,
      message: 'Portfolio updated successfully'
    });
  } catch (error) {
    console.error('Error updating portfolio:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update portfolio'
    });
  }
});

export default router;
