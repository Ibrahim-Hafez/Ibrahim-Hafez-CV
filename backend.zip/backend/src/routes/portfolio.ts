import express from 'express';
import { readFile } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Cache for portfolio data
let portfolioCache: any = null;
let cacheTimestamp: number = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

router.get('/', async (req, res) => {
  try {
    const now = Date.now();
    
    // Return cached data if still valid
    if (portfolioCache && (now - cacheTimestamp) < CACHE_DURATION) {
      return res.json(portfolioCache);
    }

    // Read portfolio data from JSON file
    const dataPath = join(__dirname, '../../data/portfolio.json');
    const data = await readFile(dataPath, 'utf-8');
    const portfolioData = JSON.parse(data);

    // Update cache
    portfolioCache = portfolioData;
    cacheTimestamp = now;

    res.json(portfolioData);
  } catch (error) {
    console.error('Error reading portfolio data:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to load portfolio data'
    });
  }
});

export default router;
