export interface PortfolioData {
  personal: PersonalInfo;
  about: string;
  skills: Skill[];
  experience: Experience[];
  education: Education[];
  projects: Project[];
  achievements: Achievement[];
  contact: ContactInfo;
}

export interface PersonalInfo {
  name: string;
  title: string;
  tagline: string;
  imageUrl?: string;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  proficiency: number;
  description?: string;
}

export interface Experience {
  id: string;
  title: string;
  organization: string;
  startDate: string;
  endDate: string | 'Present';
  description: string;
  highlights?: string[];
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  date: string;
  description?: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  categories: string[];
  technologies: string[];
  imageUrl?: string;
  links?: {
    demo?: string;
    github?: string;
    documentation?: string;
  };
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  date?: string;
}

export interface ContactInfo {
  email: string;
  phone?: string;
  location?: string;
  socialLinks: SocialLink[];
}

export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}
